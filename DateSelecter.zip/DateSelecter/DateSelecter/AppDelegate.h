//
//  AppDelegate.h
//  DateSelecter
//
//  Created by apple on 2017/8/30.
//  Copyright © 2017年 付耀辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

